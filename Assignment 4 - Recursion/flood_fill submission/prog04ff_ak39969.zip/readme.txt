To build the flood_fill executable, simply run make in this directory.

Run flood_fill by:
./flood_fill fake_picture.txt