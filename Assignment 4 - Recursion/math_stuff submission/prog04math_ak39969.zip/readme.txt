To build the math_stuff executable, simply run make in this directory

Run flood_fill by:
./math_stuff