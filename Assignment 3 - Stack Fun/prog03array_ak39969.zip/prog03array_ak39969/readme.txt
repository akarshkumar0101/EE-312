Simply type make on command line to compile and link this project.
Run using:
./driver exp.dat

(exp.dat is the file with all the equations I have tested)
This project should have no memory leaks.