Simply type make on command line to compile and link this project.
Run using:
./driver fake_picture.txt

(fake_picture.txt is the picture file that is read in)
This project should have no memory leaks.